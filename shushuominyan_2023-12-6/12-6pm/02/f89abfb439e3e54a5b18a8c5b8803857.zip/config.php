<?php
$dbhost="127.0.0.1:3306";
$username="root";
$userpass="";
$dbdatabase="ctf";
?>